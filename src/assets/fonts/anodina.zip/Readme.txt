Anodina is a font family with human features but symmetric in its soul.

You can download the entire font family for free and use in both commercial and personal projects.

https://www.brumale.xyz/anodina/
https://www.behance.net/brumale